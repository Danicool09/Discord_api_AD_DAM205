package com.amoelcodigo.crud.service;


import com.amoelcodigo.crud.entity.Usuario;
import com.amoelcodigo.crud.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class UserService {
    @Autowired
    UserRepository userRepository;

    //Por defecto el repositorio al extender de JPA trae el metodo por defecto
    public List<Usuario> listaUser(){
        return  userRepository.findAll();
    }

    public Optional<Usuario> getUser(Long id){
        return  userRepository.findById(id);
    }

    public Optional<Usuario> getByNombreUser(String nombreTorre){
        return userRepository.findByNombreUsuario(nombreTorre);
    }

    public void saveUser(Usuario user){
        userRepository.save(user);
    }

    public void deleteUser(Long id){ userRepository.deleteById(id);
    }

    public boolean existsByIdUsuario(Long id){
        return userRepository.existsById(id);
    }

    public boolean existsByNombreUsuario(String username){
        return userRepository.existsByNombreUsuario(username);
    }
}
