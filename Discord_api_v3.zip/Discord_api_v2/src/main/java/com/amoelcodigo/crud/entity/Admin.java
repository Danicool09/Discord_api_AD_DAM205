package com.amoelcodigo.crud.entity;

public enum Admin {
    ADMIN,USUARIO
}
