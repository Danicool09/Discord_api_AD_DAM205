package com.amoelcodigo.crud.entity;

import com.sun.istack.NotNull;

import javax.persistence.*;

@Entity
@Table(name = "permisos")
public class Permisos {
    @Id
    @GeneratedValue
    private Long idPermiso;
    @OneToOne
    @JoinColumn(name = "usuario_id", referencedColumnName = "id")
    private Usuario usuario;
    private String nombre;
    @NotNull
    @Enumerated
    private Admin Admin;


    @Override
    public String toString() {
        return "Peticion{" +
                "id=" + idPermiso +
                "usuario=" + usuario +
                ", titulo='" + nombre + '\'' +
                ", admin='" + Admin + '\'' +
                '}';
    }

    public Permisos(Long idPermiso, Usuario usuario, String nombre, com.amoelcodigo.crud.entity.Admin admin) {
        this.idPermiso = idPermiso;
        this.usuario = usuario;
        this.nombre = nombre;
        Admin = admin;
    }

    public Permisos() {
    }

    public Long getIdPermiso() {
        return idPermiso;
    }

    public void setIdPermiso(Long idPermiso) {
        this.idPermiso = idPermiso;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public com.amoelcodigo.crud.entity.Admin getAdmin() {
        return Admin;
    }

    public void setAdmin(com.amoelcodigo.crud.entity.Admin admin) {
        Admin = admin;
    }
}


