package com.amoelcodigo.crud.repository;

import com.amoelcodigo.crud.entity.Permisos;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PermisosRepository extends JpaRepository<Permisos, Long>{
    Optional<Permisos> findByNombrePermiso(String username);
    boolean existsByNombrePermiso(String username);
}
