package com.amoelcodigo.crud.entity;

import com.sun.istack.NotNull;


import javax.persistence.*;

@Entity
@Table(name = "servidor")
public class Servidor {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false)
    private Long id;
    private String nombre;
    @NotNull
    private int Usuarios;

    private int permisos;


    private String photo;



    @Override
    public String toString() {
        return "Peticion{" +
                "id=" + id +
                ", titulo='" + nombre + '\'' +
                ", destinatario='" + Usuarios + '\'' +
                ", permisos=" + permisos +
                '}';
    }
    @ManyToOne
    @JoinColumn(name = "usuario_id", referencedColumnName = "id")
    private Usuario usuario;

    public Servidor(Long id, String nombre, int usuarios, int permisos, String photo, Usuario usuario) {
        this.id = id;
        this.nombre = nombre;
        Usuarios = usuarios;
        this.permisos = permisos;
        this.photo = photo;
        this.usuario = usuario;
    }

    public Servidor() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getUsuarios() {
        return Usuarios;
    }

    public void setUsuarios(int usuarios) {
        Usuarios = usuarios;
    }

    public int getPermisos() {
        return permisos;
    }

    public void setPermisos(int permisos) {
        this.permisos = permisos;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
}


