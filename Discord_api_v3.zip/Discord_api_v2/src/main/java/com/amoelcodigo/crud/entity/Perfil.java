package com.amoelcodigo.crud.entity;

import javax.persistence.*;

@Entity
@Table(name = "perfil")
public class Perfil {
    @Id
    @GeneratedValue
    private long id;
    @OneToOne
    @JoinColumn(name = "usuario_id", referencedColumnName = "id")
    private Usuario usuario;
    private String nombre;

    private String banner;

    private String vinculaciones;

    @Override
    public String toString() {
        return "Peticion{" +
                "id=" + id +
                "usuario=" + usuario +
                ", titulo='" + nombre + '\'' +
                ", banner='" + banner + '\'' +
                ", vinculaciones=" + vinculaciones +
                '}';
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getBanner() {
        return banner;
    }

    public void setBanner(String banner) {
        this.banner = banner;
    }

    public String getVinculaciones() {
        return vinculaciones;
    }

    public void setVinculaciones(String vinculaciones) {
        this.vinculaciones = vinculaciones;
    }

    public Perfil(long id, Usuario usuario, String nombre, String banner, String vinculaciones) {
        this.id = id;
        this.usuario = usuario;
        this.nombre = nombre;
        this.banner = banner;
        this.vinculaciones = vinculaciones;
    }

    public Perfil() {
    }
}