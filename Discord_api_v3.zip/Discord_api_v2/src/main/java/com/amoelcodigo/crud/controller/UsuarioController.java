package com.amoelcodigo.crud.controller;

import com.amoelcodigo.crud.dto.TorreDto;
import com.amoelcodigo.crud.entity.Mensaje;
import com.amoelcodigo.crud.entity.Torre;
import com.amoelcodigo.crud.entity.Usuario;
import com.amoelcodigo.crud.service.UserService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/usuario")
@CrossOrigin(origins = "*")
public class UsuarioController {

    @Autowired
    UserService userService;

    @GetMapping("/listaUser")
    public ResponseEntity<List<Usuario>> listaUser(){

        List<Usuario> usuarios = userService.listaUser();
        return new ResponseEntity<List<Usuario>>(usuarios, HttpStatus.OK);
    }

    @GetMapping("/detalleUsuario/{id}")
    public ResponseEntity<Torre> torreById(@PathVariable("id") Long id){

        if (!userService.existsByIdUsuario(id))
            return new ResponseEntity(new Mensaje("No existe la torre"), HttpStatus.NOT_FOUND);

        Usuario usuario = userService.getUser(id).get();
        return new ResponseEntity(usuario, HttpStatus.OK);
    }

    @GetMapping("/detalleNombre/{username}")
    public ResponseEntity<Torre> torreByNombre(@PathVariable("username") String username){

        if (!userService.existsByNombreUsuario(username))
            return new ResponseEntity(new Mensaje("No existe la torre"), HttpStatus.NOT_FOUND);

        Usuario usuario = userService.getByNombreUser(username).get();
        return new ResponseEntity(usuario, HttpStatus.OK);
    }

    //Con el ? le decimos que no devulve ningún tipo de dato
    //El body va a ser un JSON
    //Aqui se usa el apache commons lang
    // El import de StringUtils es import org.apache.commons.lang3.StringUtils;
    @PostMapping("/crearTorre")
    public ResponseEntity<?> creaTorre(@RequestBody Usuario usuario){

        if(StringUtils.isBlank(usuario.getUsername()))
            return new ResponseEntity(new Mensaje("El nombre es obligatorio"), HttpStatus.BAD_REQUEST);

        new Usuario(usuario.getName(),usuario.getEmail(),usuario.getPassword(),usuario.getUsername());
       userService.saveUser(usuario);
        return new ResponseEntity(new Mensaje("Torre creada"), HttpStatus.OK);
    }

    @PutMapping("/actualizarTorre/{id}")
    public ResponseEntity<?> actualizarTorre(@PathVariable("id") Long id, @RequestBody TorreDto torreDto){

        if (!userService.existsByIdUsuario(id))
        return new ResponseEntity(new Mensaje("No existe la torre"), HttpStatus.NOT_FOUND);

        if (torreService.existsByNombreTorre(torreDto.getNombreTorre())
                && torreService.getByNombreTorre(torreDto.getNombreTorre()).get().getIdTorre() != idTorre)
            return new ResponseEntity(new Mensaje("El nombre de la torre ya existe"), HttpStatus.NOT_FOUND);

        if(StringUtils.isBlank(torreDto.getNombreTorre()))
            return new ResponseEntity(new Mensaje("El nombre es obligatorio"), HttpStatus.BAD_REQUEST);

        if(torreDto.getCantidadAptos()<0 || (Integer) torreDto.getCantidadAptos() == null)
            return new ResponseEntity(new Mensaje("La cantidad de aptos debe ser mayor a 0"), HttpStatus.BAD_REQUEST);

        Torre torre = torreService.getTorre(idTorre).get();
        torre.setNombreTorre(torreDto.getNombreTorre());
        torre.setCantidadAptos(torreDto.getCantidadAptos());
        torreService.saveTorre(torre);
        return new ResponseEntity(new Mensaje("Torre actualizada"), HttpStatus.OK);
    }

    @DeleteMapping("/borrarTorre/{idTorre}")
    public ResponseEntity<?> borrarTorre(@PathVariable("idTorre") int idTorre){
        if (!torreService.existsByIdTorre(idTorre))
            return new ResponseEntity(new Mensaje("No existe la torre"), HttpStatus.NOT_FOUND);
        torreService.deleteTorre(idTorre);
        return new ResponseEntity(new Mensaje("Torre eliminada"), HttpStatus.OK);
    }

}
